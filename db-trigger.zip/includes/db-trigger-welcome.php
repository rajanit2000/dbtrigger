<div class="wrap">
	<h1>Trigger</h1>

	<?php settings_fields( 'trigger-db-settings-group' ); 
	do_settings_sections( 'trigger-db-settings-group' ); ?>
	
	<p>System info here</p>
	
</div>